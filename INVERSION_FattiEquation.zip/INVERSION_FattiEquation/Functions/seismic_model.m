function [f, synth] = seismic_model(x)
% Computes seismic forward model
load params.mat data weight dt t0 wav ipscale isscale rhoscale ip0 is0 rho0...
    theta alpha_ip alpha_is alpha_rho mute norm;

Nl = (length(x))/3;
ip = ip0 + ipscale*x(1:Nl);
is = is0 + isscale*x(1+Nl:2*Nl);
rho = rho0 + rhoscale*x(1+2*Nl:3*Nl);

t0_i = floor(t0/dt);
%% Data error and grad
trc = Fatti_equation(ip, is, rho, theta);
synth = conv2(wav, trc);
synth = synth(1+t0_i:Nl+t0_i,:);
J = 0.5*sum(sum((data - synth).^2));

%% Model error and grad: %display('Computing Regularization gradient')
fm = 0.5*alpha_ip*sum((ip - ip0).^2); 
fm = fm + 0.5*alpha_is*sum((is-is0).^2);
fm = fm + 0.5*alpha_rho*sum((rho-rho0).^2);


%% Scaling and Muting: display('Scaling and muting')
f = J + fm;

