function [f, g] = AS_Grad_FattiEquation(x)
load  params.mat data weight dt t0 wav ipscale isscale rhoscale ip0 is0 rho0...
    theta alpha_ip alpha_is alpha_rho mute norm;

Nl = (length(x))/3;
ip = ip0 + ipscale*x(1:Nl);             % P-impedance
is = is0 + isscale*x(1+Nl:2*Nl);        % S-impedance
rho = rho0 + rhoscale*x(1+2*Nl:3*Nl);   % Density

t0_i = floor(t0/dt);
%% Data error and grad
trc = Fatti_equation(ip, is, rho, theta);
synth = conv2(wav, trc);
synth = synth(1+t0_i:Nl+t0_i,:);
J = 0.5*sum(sum((data - synth).^2));

res = data-synth;        
res = conv2(wav, res);
res = res(1+t0_i:Nl+t0_i,:);
g=zeros(3*Nl,1);

sin2 = sin(theta).^2;
tan2 = tan(theta).^2;
for i = 2:Nl-1
    dip0 = ip(i) - ip(i-1);
    dip1 = ip(i+1) - ip(i);
    dis0 = is(i) - is(i-1);
    dis1 = is(i+1) - is(i);
    drho0 = rho(i) - rho(i-1);
    drho1 = rho(i+1) - rho(i);
    ipm0 = (ip(i) + ip(i-1))/2;
    ipm1 = (ip(i+1) + ip(i))/2;
    ism0 = (is(i) + is(i-1))/2;
    ism1 = (is(i+1) + is(i))/2;
    rhom0 = (rho(i) + rho(i-1))/2;    
    rhom1 = (rho(i+1) + rho(i))/2;

% P-impedance gradient
g(i) = sum(0.5*(1 + (tan2)).*(1/ipm1 + dip1/(2*(ipm1^2))).*res(i,:),2); 
g(i) = g(i,:) + sum(0.5*(1 + (tan2)).*(-1/ipm0 + dip0/(2*(ipm0^2))).*res(i-1,:),2);
g(i) = g(i,:) + sum(4 * ism0 .* dis0 ./ (ipm0.^3) .* sin2 .* res(i-1,:),2); 
g(i) = g(i,:) + sum(4 * ism1 .* dis1 ./ (ipm1.^3) .* sin2 .* res(i,:),2);
g(i) = g(i,:) - sum( 2 * (ism0.^2) ./ (ipm0.^3) .* (drho0 ./ rhom0) .* sin2 .* res(i-1,:), 2 ); 
g(i) = g(i,:) - sum( 2 * (ism1.^2) ./ (ipm1.^3) .* (drho1 ./ rhom1) .* sin2 .* res(i,:), 2 );
% S-impedance gradient
g(i+Nl) = g(i+Nl) + sum( 4 * ism0 ./ (ipm0.^2) .* sin2 .* res(i-1,:), 2 );
g(i+Nl) = g(i+Nl) - sum( 4 * ism1 ./ (ipm1.^2) .* sin2 .* res(i,:), 2 );
g(i+Nl) = g(i+Nl) + sum( 4 * dis0 ./ (ipm0.^2) .* sin2 .* res(i-1,:), 2 );
g(i+Nl) = g(i+Nl) + sum( 4 * dis1 ./ (ipm1.^2) .* sin2 .* res(i,:), 2 );
g(i+Nl) = g(i+Nl) - sum( 2 * (ism0 ./ (ipm0.^2)) .* (drho0 ./ rhom0) .* sin2 .* res(i-1,:), 2 );
g(i+Nl) = g(i+Nl) - sum( 2 * (ism1 ./ (ipm1.^2)) .* (drho1 ./ rhom1) .* sin2 .* res(i,:), 2 );
% Density gradient
g(i+2*Nl) = g(i+2*Nl) - sum(((0.5*tan2 -(2*(ism1./ipm1).^2).*sin2).*(1/rhom1 + drho1./(2*(rhom1.^2))).*res(i,:)),2);
g(i+2*Nl) = g(i+2*Nl) - sum(((0.5*tan2 -(2*(ism0./ipm0).^2).*sin2).*(-1/rhom0 + drho0./(2*(rhom0.^2))).*res(i-1,:)),2); 
end

g(1) = g(2);
g(Nl) = g(Nl-1);
g(1+Nl) = g(2+Nl);
g(2*Nl) = g(2*Nl-1);
g(1+2*Nl) = g(2+2*Nl);
g(3*Nl) = g(3*Nl-1);
%% Model error and grad - display('Computing Regularization gradient');
fm = 0.5*alpha_ip*sum((ip - ip0).^2); 
fm = fm + 0.5*alpha_is*sum((is-is0).^2);
fm = fm + 0.5*alpha_rho*sum((rho-rho0).^2);
g(1:Nl) = g(1:Nl) + alpha_ip*(ip - ip0);
g(1+Nl:2*Nl) = g(1+Nl:2*Nl) + alpha_is*(is - is0);
g(1+2*Nl:3*Nl) = g(1+2*Nl:3*Nl) + alpha_rho*(rho-rho0);
%% Scaling and Muting - display('Scaling and muting');
g(1:Nl)=g(1:Nl)*ipscale;
g(1+Nl:2*Nl)=g(1+Nl:2*Nl)*isscale;
g(1+2*Nl:3*Nl)=g(1+2*Nl:3*Nl)*rhoscale;
g(1:Nl)=g(1:Nl).*mute;
g(1+Nl:2*Nl)=g(1+Nl:2*Nl).*mute;
g(1+2*Nl:3*Nl)=g(1+2*Nl:3*Nl).*mute;

f = J + fm;
