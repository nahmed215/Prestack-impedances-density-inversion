function Rpp = Fatti_equation(ip, is, rho, theta)

Nt = length(ip);
Ntheta = length(theta);
Rpp = zeros(Nt,Ntheta);
sin2 = sin(theta).^2;
tan2 = tan(theta).^2;

for i = 1:Nt-1
    dip = ip(i+1) - ip(i);
    dis = is(i+1) - is(i);
    drho = rho(i+1) - rho(i);
    ipm = (ip(i+1) + ip(i))/2;
    ism = (is(i+1) + is(i))/2;
    rhom = (rho(i+1) + rho(i))/2;

    Rpp(i,:) = 0.5*(1 + (tan2)).*(dip./ipm)...
        - 4*(((ism./ipm)^2)*dis/ism).*sin2...
        - (0.5*tan2-2*(ism./ipm)^2.*sin2).*(drho/rhom);

end

