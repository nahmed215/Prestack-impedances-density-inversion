function [ x, g, f, info, count, img] = linesearch_backtrack_ms(fg, xp, f, g, s1, s2, stp1, stp2, ftol,wolfe, max_linesearch, min_step, max_step,linesearch_type)

x=xp;
% ret=0;
% width=0;
% dg=0;
% norm=0;
% finit=0;
% dginit=0;
% dgtest=0;
dec=.5;
inc=2.1;
count=0;
info=0;


%     /* Check the input parameters for errors. */
if (stp1 <= 0.)
    info=999;
    return;
end
if (stp2 <= 0.)
    info=999;
    return;
end

N = size(g,1);
N1 = N/2;
g1=g(1:N1);
g2=g(1+N1:2*N1);
%     /* Compute the initial gradient in the search direction. */
dginit1=sum(g1.*s1);
dginit2=sum(g2.*s2);
dginit=dginit1+dginit2;


%     /* Make sure that s points to a descent direction. */
if (0 < dginit1)
    info=998;
    return;
end
if (0 < dginit2)
    info=998;
    return;
end


%     /* The initial value of the objective function. */
finit = f;
dgtest1 = ftol * dginit1;
dgtest2 = ftol * dginit2;

while (1)
    x=xp;
    x(1:N1)=x(1:N1)+ stp1*s1;
    x(1+N1:2*N1)=x(1+N1:2*N1)+ stp2*s2;
    
    
    if (nargout>5)
        [f,g,img]=feval(fg,x);
    else
        [f,g]=feval(fg,x);
    end
    
    g1=g(1:N1);
    g2=g(1+N1:2*N1);
    
    count=count+1;

    if (f > (finit + (stp1 * dgtest1) + (stp2 * dgtest2)))
        width = dec;
    else
%         display('testing linesearch');
        %             /* The sufficient decrease condition (Armijo condition). */
        if (linesearch_type == 1)
            %                 /* Exit with the Armijo condition. */
%             display('Armijo');
            return;
        end
        
        
        % 	        /* Check the Wolfe condition. */
        dg=sum(g1.*s1) + sum(g2.*s2);
        
        if (dg < wolfe * dginit)
            width = inc;
        else
            if(linesearch_type == 2)
                % 		            /* Exit with the regular Wolfe condition. */
%                 display('Wolfe');
                return;
            end
        end
        
        % 		        /* Check the strong Wolfe condition. */
        if(dg > -wolfe * dginit)
            width = dec;
        else
            % 		            /* Exit with the strong Wolfe condition. */
%             display('Strong wolfe');
            return;
        end
    end
    
    
    if (stp1 < min_step || stp2 < min_step)
        %             /* The step is the minimum value. */
        info=997;
        return;
    end
    if (stp1 > max_step || stp2 > max_step)
        %             /* The step is the maximum value. */
        info=996;
        return;
    end
    if (max_linesearch <= count)
        %             /* Maximum number of iteration. */
        info=995;
        return;
    end
    
    stp1 = stp1*width;
    stp2 = stp2*width;
end
end



