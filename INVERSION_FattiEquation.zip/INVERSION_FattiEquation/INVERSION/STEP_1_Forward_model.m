clc, clear all, close all

path(path,'../Functions')
%% Inputs
load('elastic_inputs.mat','VP','VS','RH','t');  % True / reference properties and time

ip = VP.*RH; is = VS.*RH;  % Compute P and S-impedances

nt = 101;     % number of layers
ti = t./1000; % Time in sec.

ip0 = ip; is0 = is; rho0 = RH; vp = VP; vs = VS; rho = RH; % for initial models
%% Wavelet
dt = ti(2)-ti(1);
f0 = 40;       % frequency
t0 = 2/f0;
[wav,t] = RickerWavelet(f0, t0, nt, dt);
wav = wav.'; t0_i = floor(t0/dt);
time = ti;  % time
%% Angles
angles = 0:45;
theta = angles*pi/180;
%% Make weight
weight = ones(nt,1);
data = weight;
%% Inversion starts here (This section is not necessarily required here 
% in forward modeling code

kip = 50000.0;
kis = 50000.0;
krho = 20.0;

ipscale=kip; 
isscale=kis; 
rhoscale=krho;

xi = zeros(3*nt,1); 

norm = 1;
mute = ones(size(ip0));

alpha_ip = 0e-6;
alpha_is = 0e-6;
alpha_rho = 0e-6;
% Save params
save params.mat data weight dt t0 wav ipscale isscale rhoscale ip0 is0 rho0 theta alpha_ip alpha_is alpha_rho mute norm;

%% Forward model 
[~,data] = seismic_model(xi);
% adding random noise
rng('default')
seis = var(data); SNR = 20;
var_noise = var(data)./SNR;
std_noise = sqrt(seis./SNR);
Noise_data = data + std_noise.*randn(size(data));
data = Noise_data;
%% Initial model - smoothing the true models
ip0 = vel_smoother(ip0,128, .07, 1); 
is0 = vel_smoother(is0,128, .07, 1);
rho0 = vel_smoother(rho0,128, .07, 1);
%% Save data and wavelet
save True_model ip is rho;               % Save true model
save Initial_model.mat ip0 is0 rho0;     % Save initial model
save Observed_data.mat data angles time; % Save bserved models
save Wavelet.mat wav dt t0;              % Save seismic wavelet
%save vpvs.mat vp vs;

%% Plotting - a quick plot

figure, subplot(131);
plot(ip,time); hold on; plot(ip0,time,'--r'); set(gca, 'ydir', 'reverse');
xlabel(['I_P']); ylabel(['Time (sec)']);
ylim([2 2.2]);

subplot(132);
plot(is,time); hold on; plot(is0,time,'--r'); set(gca, 'ydir', 'reverse');
xlabel(['I_S']); ylabel([]); set(gca,'YTickLabel',[]);
ylim([2 2.2]);

subplot(133);
plot(rho,time); hold on; plot(rho0,time,'--r'); set(gca, 'ydir', 'reverse');
xlabel(['Rho']); ylabel([]); set(gca,'YTickLabel',[]);
ylim([2 2.2]);

theta = [1, 6 12 18 24 30];
gather1 = data(:,1); gather6 = data(:,6); gather12 = data(:,12); gather18 = data(:,18);
gather24 = data(:,24); gather30 = data(:,30); 
gather = [gather1,gather6,gather12,gather18,gather24,gather30];

figure, 
wiggle(gather,time,theta); 
xlabel('Angle (deg)'); ylabel('Time (ms)'); 
title('SNR = 20','fontweight','normal'); 
set(gcf, 'position', [600         285        285         550]); 
