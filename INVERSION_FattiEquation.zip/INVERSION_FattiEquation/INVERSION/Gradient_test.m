clear all,
clc,
close all
norm = 1;
path(path,'../Functions')
%% Load data
load Observed_data.mat data angles time;
load Wavelet.mat wav dt t0;
load Initial_model.mat ip0 is0 rho0;
Nl = length(time);
t0_i = floor(t0/dt);
theta = angles*pi/180;
weight = ones(size(data));

%% Inversion starts here
kip = 50000.0;
kis = 50000.0;
krho = 15.0;

ipscale=kip; 
isscale=kis; 
rhoscale=krho;

xi = zeros(3*Nl,1); 

mute = ones(size(ip0));
mute(1:1) = 0;

alpha_ip = 0.1e-16;
alpha_is = 0.05e-16;
alpha_rho = 0.028e-18;
% Save params
save params.mat data weight dt t0 wav ipscale isscale rhoscale ip0 is0 rho0...
    theta alpha_ip alpha_is alpha_rho mute norm;

%% Compute gradients
dxi = 1e-9;
fdgrad = zeros(3*Nl,1); 
range = 1:3*Nl;
tic
for i=range
    xipert = xi;
    xipert(i) = xi(i) + dxi;
    fp = AS_Grad_FattiEquation(xipert);
    xipert = xi;
    xipert(i) = xi(i) - dxi;
    fm = AS_Grad_FattiEquation(xipert);
    fdgrad(i) = (fp-fm)/(2*dxi);
    disp(i);
end
disp("Cost of FD:"); %FD - finite difference approximation
toc
tic
[f,g] = AS_Grad_FattiEquation(xi); % AD - adjoint gradient
disp("Cost of AS:");
toc
%%
range1 = (1:Nl);
range2 = (1:Nl) + Nl;
range3 = (1:Nl) + 2*Nl;
fdvpfati = fdgrad(range1);
asvpfati = g(range1);
fdvsfati = fdgrad(range2);
asvsfati = g(range2);
fdrhfati = fdgrad(range3);
asrhfati = g(range3);

%%
figure
range = (1:Nl);
subplot(311); plot(fdgrad(range),'b', 'LineWidth',0.8);
hold on, plot(g(range), "--r", 'LineWidth',0.8);
xlim([1 101]); ylim([-0.06 0.06]);
title("P-impedance",'fontweight','normal');  
xlabel([]); %set(gca,'YTickLabel',[]);
set(gca,'xtick',[]); ylabel('Amplitude');
set(gca, 'fontsize', 10,'fontweight','normal'); 

range = (1:Nl) + Nl;
subplot(312); plot(fdgrad(range),'b', 'LineWidth',0.8);
hold on, plot(g(range),  "--r", 'LineWidth',0.8);
xlim([1 101]); ylim([-0.05 0.05]);
title("S-impedance",'fontweight','normal'); 
xlabel(['Number of layers']);
set(gca,'xtick',[1:50:101]); ylabel('Amplitude');
set(gca, 'fontsize', 10,'fontweight','normal'); xlabel([]); set(gca,'XTickLabel',[]);

range = (1:Nl) + 2*Nl;
subplot(313); plot(fdgrad(range),'b', "displayname", "FD", 'LineWidth',0.8);
hold on, plot(g(range),  "--r", "displayname", "AS", 'LineWidth',0.8);
xlim([1 101]); ylim([-0.01 0.01]); 
title("Density",'fontweight','normal'); 
xlabel(['Number of layers']); ylabel('Amplitude');
set(gca,'xtick',[1:50:101]); % ylabel([]); set(gca,'YTickLabel',[]);
set(gca, 'fontsize', 10,'fontweight','normal'); 
legend("location", "northeast");

set(gcf, 'position', [600         285        550         450]); 

Lgnd = legend('show');
Lgnd.Position(1) = 0.42;
Lgnd.Position(2) = 0.247;
set(gca, 'fontsize', 9.0);
legend('Orientation','horizontal');

%print(gcf,'F_grad_plt.jpg','-dpng','-r600');