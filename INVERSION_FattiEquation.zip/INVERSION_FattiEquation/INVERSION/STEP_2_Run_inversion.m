clear all, clc, close all,
norm = 1;
tic
path(path,'../Functions')
%% Loading the required data
load Observed_data.mat data angles time; % Seismic data
load Wavelet.mat wav dt t0;              % Wavelet
load Initial_model.mat ip0 is0 rho0;     % Initial model
load True_model.mat                      % True models
Nl = length(time);
t0_i = floor(t0/dt);
theta = angles*pi/180;     % incident angles
weight = ones(size(data)); % Make weight

%% Inversion starts here ######################################
kip = 50000.0;     % Scalling factors - P-impedance
kis = 50000.0;     % Scalling factors - S-impedance
krho = 25.0;       % Scalling factors - Density

ipscale=kip; 
isscale=kis; 
rhoscale=krho;

xi = zeros(3*Nl,1);
% Parameters
mute = ones(size(ip0));
mute(1:1) = 0;

alpha_ip = 0; % Regularization - Tikhonov
alpha_is = 0;
alpha_rho = 0.1e-7;
% Save params
save params.mat data weight dt t0 wav ipscale isscale rhoscale ip0 is0 rho0...
    theta alpha_ip alpha_is alpha_rho mute norm;
%% Run inversion using L-BFGS
[xo, hist, iters]=wei_lbfgs_hess('AS_Grad_FattiEquation', xi, 10, 250, 3, 10, 1e-4, .9, 1e-4, 1e-12, 1e-16);

%% Plot results
ipf = ip0+xo(1:Nl,end)*ipscale;            % P-impedance - inverted model
isf = is0+xo(1+Nl:2*Nl,end)*isscale;       % S-impedance - inverted model
rhof = rho0+xo(1+2*Nl:3*Nl,end)*rhoscale;  % Density - inverted model

[~,modf] = seismic_model(xo(:,end)); % Seismic data from inverted models
[~,mod0] = seismic_model(xi);        % Seismic data from initial models

t = time;

% INversion results
figure,
subplot(1,3,1);
    plot(ip./1e+06,t.*1000, 'k', 'displayname', 'True model', 'linewidth', 1.2);
    hold on,
    plot(ip0./1e+06,t.*1000, 'r', 'linestyle', '--', 'displayname', 'Initial model', 'linewidth', 1.0);
    plot(ipf./1e+06,t.*1000, 'g', 'displayname', 'Inverted model', 'linewidth', 1.0);

    grid on; set(gca,'GridLineStyle','--');
    axis([5 9 2000 2200]); 

    xlabel({'P wave impedance','(km/s . g/cm^3)'}, 'FontSize', 9); 
    ylabel('Time (ms)', 'FontSize', 10);

    set(gca,'xtick',[5:2:9]); 
    set(gca,'ytick',[2000:40:2200]);

    set(gca, 'fontsize', 10.0,'fontweight','normal'); 
    set(gca,'ydir','reverse');
            
subplot(1,3,2);
    plot(is./1e+06,t.*1000, 'k', 'displayname', 'True model', 'linewidth', 1.2);
    hold on, 
    plot(is0./1e+06,t.*1000, 'r', 'linestyle', '--', 'displayname', 'Initial model', 'linewidth', 1.0);
    plot(isf./1e+06,t.*1000, 'g', 'displayname', 'Inverted model', 'linewidth', 1.0);

    xlabel({'S wave impedance','(km/s . g/cm^3)'}, 'FontSize', 10); 
    ylabel('Time (ms)'); 

    axis([2 5 2000 2200]); 
    grid on; set(gca,'GridLineStyle','--');
    set(gca,'xtick',[2:1.5:5]); set(gca,'ytick',[]);  
    set(gca,'ytick',[2000:40:2200]);
    ylabel([]); set(gca,'YTickLabel',[]); 

    set(gca, 'fontsize', 10.0,'fontweight','normal'); 
    set(gca,'ydir','reverse');
            
subplot(1,3,3);
    plot(rho./1000,t.*1000, 'k', 'displayname', 'True model', 'linewidth', 1.2);
    hold on, 
    plot(rho0./1000,t.*1000, 'r', 'linestyle', '--', 'displayname', 'Initial model', 'linewidth', 1.0);
    plot(rhof./1000,t.*1000, 'g', 'displayname', 'Inverted model', 'linewidth', 1.0);

    xlabel({'Density','(g/cm^3)'}, 'FontSize', 10); 
    
    axis([2.1 2.5 2000 2200]); 
    set(gca,'ydir','reverse');
    grid on; set(gca,'GridLineStyle','--');

    set(gca,'xtick',[2.100:0.2:2.500]); 
    set(gca,'ytick',[]);  
    set(gca,'ytick',[2000:40:2200]);
    ylabel([]); set(gca,'YTickLabel',[]); 

    set(gca, 'fontsize', 10.0,'fontweight','normal'); 
    
sgtitle({'Single-step inversion with','limited memory quasi-Newton'}, 'FontSize', 12);

set(gcf, 'position', [500         285        500         400]); 

% add legend
Lgnd = legend('show');
Lgnd.Position(1) = 0.395;
Lgnd.Position(2) = 0.775;
set(gca, 'fontsize', 11.0);
legend('Orientation','horizontal');

%print(gcf,'F_NEWGRD_plt.jpg','-dpng','-r600');