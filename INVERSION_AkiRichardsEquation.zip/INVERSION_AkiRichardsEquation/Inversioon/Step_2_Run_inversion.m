clear all, clc,
close all
norm = 1;
path(path,'../functionSnr20')
tic

%% Load shot data
load Observed_data.mat data angles time;
load Wavelet.mat wav dt t0; % Load wavelet
load Initial_model.mat ip0 is0 rho0; % Load initial model
load vpvs.mat vp vs;
load True_model.mat

Nl = length(time);
t0_i = floor(t0/dt);
theta = angles*pi/180;
weight = ones(size(data)); %% Make weight

%% Inversion starts here
kip = 50000.0;
kis = 50000.0;
krho = 25.0;

ipscale=kip; 
isscale=kis; 
rhoscale=krho;

xi = zeros(3*Nl,1); 

% Parameters
mute = ones(size(ip0));
mute(1:1) = 0;

alpha_ip = 0; % Tikho Regularization
alpha_is = 0;
alpha_rho = 0.1e-7;
% Save params
save params.mat data weight dt t0 wav vp vs ipscale isscale rhoscale ip0 is0 rho0 theta alpha_ip alpha_is alpha_rho mute norm;
%% Run inversion using L-BFGS
[xo, hist, iters]=wei_lbfgs_hess('AS_Grad_AkiR_Eq', xi, 10, 200, 3, 10, 1e-4, .9, 1e-4, 1e-12, 1e-16);
%% Plot results
ipf = ip0+xo(1:Nl,end)*ipscale;
isf = is0+xo(1+Nl:2*Nl,end)*isscale;
rhof = rho0+xo(1+2*Nl:3*Nl,end)*rhoscale;

[~,modf] = Fwmod_model(xo(:,end));
[~,mod0] = Fwmod_model(xi);

%% INversion results
t = time; 

figure,
subplot(1,3,1);
    plot(ip./1e+06,t.*1000, 'k', 'displayname', 'True model', 'linewidth', 1.2);
    hold on,
    plot(ip0./1e+06,t.*1000, 'r', 'linestyle', '--', 'displayname', 'Initial model', 'linewidth', 1.0);
    plot(ipf./1e+06,t.*1000, 'g', 'displayname', 'Inverted model', 'linewidth', 1.0);

    grid on; set(gca,'GridLineStyle','--');
    axis([5 9 2000 2200]); 

    xlabel({'P wave impedance','(km/s . g/cm^3)'}, 'FontSize', 9); 
    ylabel('Time (ms)', 'FontSize', 10);

    set(gca,'xtick',[5:2:9]); 
    set(gca,'ytick',[2000:40:2200]);

    set(gca, 'fontsize', 10.0,'fontweight','normal'); 
    set(gca,'ydir','reverse');
            
subplot(1,3,2);
    plot(is./1e+06,t.*1000, 'k', 'displayname', 'True model', 'linewidth', 1.2);
    hold on, 
    plot(is0./1e+06,t.*1000, 'r', 'linestyle', '--', 'displayname', 'Initial model', 'linewidth', 1.0);
    plot(isf./1e+06,t.*1000, 'g', 'displayname', 'Inverted model', 'linewidth', 1.0);

    xlabel({'S wave impedance','(km/s . g/cm^3)'}, 'FontSize', 10); 
    ylabel('Time (ms)'); 

    axis([2 5 2000 2200]); 
    grid on; set(gca,'GridLineStyle','--');
    set(gca,'xtick',[2:1.5:5]); set(gca,'ytick',[]);  
    set(gca,'ytick',[2000:40:2200]);
    ylabel([]); set(gca,'YTickLabel',[]); 

    set(gca, 'fontsize', 10.0,'fontweight','normal'); 
    set(gca,'ydir','reverse');
            
subplot(1,3,3);
    plot(rho./1000,t.*1000, 'k', 'displayname', 'True model', 'linewidth', 1.2);
    hold on, 
    plot(rho0./1000,t.*1000, 'r', 'linestyle', '--', 'displayname', 'Initial model', 'linewidth', 1.0);
    plot(rhof./1000,t.*1000, 'g', 'displayname', 'Inverted model', 'linewidth', 1.0);

    xlabel({'Density','(g/cm^3)'}, 'FontSize', 10); 
    
    axis([2.1 2.5 2000 2200]); 
    set(gca,'ydir','reverse');
    grid on; set(gca,'GridLineStyle','--');

    set(gca,'xtick',[2.100:0.2:2.500]); 
    set(gca,'ytick',[]);  
    set(gca,'ytick',[2000:40:2200]);
    ylabel([]); set(gca,'YTickLabel',[]); 

    set(gca, 'fontsize', 10.0,'fontweight','normal'); 
    
sgtitle({'Single-step inversion with','limited memory quasi-Newton'}, 'FontSize', 12);

set(gcf, 'position', [500         285        500         400]); 

% add legend
Lgnd = legend('show');
Lgnd.Position(1) = 0.395;
Lgnd.Position(2) = 0.775;
set(gca, 'fontsize', 11.0);
legend('Orientation','horizontal');

%print(gcf,'F_NEWGRD_plt.jpg','-dpng','-r600');
toc