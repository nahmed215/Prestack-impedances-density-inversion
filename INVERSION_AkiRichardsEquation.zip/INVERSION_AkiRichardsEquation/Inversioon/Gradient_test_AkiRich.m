clear all, clc,
close all
norm = 1;
path(path,'../functionSnr20')


%% Load shot data
load Observed_data.mat data angles time;
load('vpvs.mat')
Nl = length(time);

%% Load wavelet
load Wavelet.mat wav dt t0;
t0_i = floor(t0/dt);

%% Load initial model
load Initial_model.mat ip0 is0 rho0;

%% Angles
theta = angles*pi/180;
%% Make weight
weight = ones(size(data));

%% Inversion starts here
kip = 50000.0;
kis = 50000.0;
krho = 15.0;

ipscale=kip; 
isscale=kis; 
rhoscale=krho;

xi = zeros(3*Nl,1); 

%% Parameters
mute = ones(size(ip0));
mute(1:1) = 0;

alpha_ip = 0.1e-16;
alpha_is = 0.05e-16;
alpha_rho = 0.028e-18;
%% Save params
save params.mat data weight dt t0 wav vp vs ipscale isscale rhoscale ip0 is0 rho0 theta alpha_ip alpha_is alpha_rho mute norm;

%% Compute gradients
dxi = 1e-3;
fdgrad = zeros(3*Nl,1); 
range = 1:3*Nl;
tic
for i=range
    xipert = xi;
    xipert(i) = xi(i) + dxi;
    fp = AS_Grad_AkiR_Eq(xipert);
    xipert = xi;
    xipert(i) = xi(i) - dxi;
    fm = AS_Grad_AkiR_Eq(xipert);
    fdgrad(i) = (fp-fm)/(2*dxi);
    disp(i);
end
disp("Cost of FD:");
toc
tic
[f,g] = AS_Grad_AkiR_Eq(xi);
disp("Cost of AS:");
toc
%%
range1 = (1:Nl);
range2 = (1:Nl) + Nl;
range3 = (1:Nl) + 2*Nl;
fdvpaki = fdgrad(range1);
asvpaki = g(range1);
fdvsaki = fdgrad(range2);
asvsaki = g(range2);
fdrhaki = fdgrad(range3);
asrhaki = g(range3);
save Aki_gradient.mat fdvpaki asvpaki fdvsaki asvsaki fdrhaki asrhaki
%%
close all
range = (1:Nl);
figure, subplot(311); plot(fdgrad(range),'b', "displayname", "FD",'LineWidth',1.0);
hold on, plot(g(range), "--r", "displayname", "AS",'LineWidth',1.5);
legend("location", "northeast"); xlim([0 101]); %ylim([-0.1 0.1]);
title("P impedance gradient"); ylabel('Amplitude');
 set(gca,'xtick',[]);
range = (1:Nl) + Nl;
subplot(312); plot(fdgrad(range),'b', "displayname", "FD",'LineWidth',1.0);
hold on, plot(g(range),  "--r", "displayname", "AS",'LineWidth',1.5);
legend("location", "northeast"); ylabel('Amplitude');
title("S impedance  gradient"); xlim([0 101]); %ylim([-0.04 0.04]);
 set(gca,'xtick',[]);
range = (1:Nl) + 2*Nl;
subplot(313); plot(fdgrad(range),'b', "displayname", "FD",'LineWidth',1.0);
hold on, plot(g(range),  "--r", "displayname", "AS",'LineWidth',1.5);
legend("location", "northeast"); xlim([0 101]); %ylim([-0.05 0.05]);
title("Density gradient"); xlabel(['Number of layers']);
set(gca,'xtick',[0:50:101]); ylabel('Amplitude');