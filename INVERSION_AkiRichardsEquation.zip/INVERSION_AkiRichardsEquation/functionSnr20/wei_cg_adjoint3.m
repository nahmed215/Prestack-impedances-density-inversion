function [xout, hist, iters, f_values] = wei_cg_adjoint3(fg, x, max_iterations, ftol, gtol)

    % INputs
    % fg: The name of the function that computes both the objective function 
    % value and its gradient (using adjoint state methods).
    % x: Initial guess of the parameters to optimize.
    % max_iterations: The maximum number of iterations for the optimization.
    % ftol: The tolerance for changes in the function value (i.e., if changes
    % in f between iterations are less than ftol, stop).
    % gtol: The tolerance for the gradient norm (i.e., if the gradient becomes 
    % smaller than this value, stop).

    % Outputs
    % xout: The optimized parameters.
    % hist: The history of function values (used for monitoring progress).
    % iters: The number of iterations performed.
    % f_values: The array storing the function values at each iteration.

    % Initialization
    n = length(x);
    xout = zeros(n, 1);
    hist = [];        % Store the history of function values
    f_values = [];    % Initialize an empty array to store function values
    iters = 0;

    % Main Loop
    while iters < max_iterations
        % Call the objective function and gradient
        [f, g] = feval(fg, x);  % Get function value and adjoint-state gradient

        % Save the current function value
        f_values(end + 1) = f;  % Append the function value to the list

        % Solve the system using Conjugate Gradient (CG) without Hessian-vector product
        d = conj_grad(g, gtol);  % Use CG to get the search direction

        % Update the parameters
        x_new = x + d;

        % Check the function value at the new point
        [f_new, g_new] = feval(fg, x_new);

        % Display iteration information in the command window
        disp(['Iteration: ', num2str(iters), ' | Function Value: ', num2str(f), ' | Gradient Norm: ', num2str(norm(g))]);

        % Check convergence
        if norm(g_new) < gtol || abs(f_new - f) < ftol
            break; % Stop if the gradient is small enough or function value converges
        end

        if iters >= max_iterations
            break;
        end

        % Store the history for later plotting
        hist(end + 1) = f; % Store the objective function value
        iters = iters + 1; % Increment iteration count

        % Update x for the next iteration
        x = x_new;
    end

    xout = x; % Return optimized parameters
end

% Conjugate Gradient function (simplified for optimization context)
function d = conj_grad(g, tol)
    % Conjugate Gradient method for minimizing f(x)
    % g is the gradient vector, we are solving for direction d where grad(f(x)) = 0

    x = zeros(size(g));  % Initial guess (direction)
    r = g;  % Initial residual (using gradient here)
    p = -r;  % Initial search direction is the negative gradient

    for iter = 1:length(g)
        % Calculate step size
        alpha = (r' * r) / (p' * p);  
        
        % Update solution
        x = x + alpha * p;
        
        % Update residual
        r_new = r + alpha * p;
        
        % Check for convergence
        if norm(r_new) < tol
            break;
        end

        % Update search direction
        beta = (r_new' * r_new) / (r' * r);
        p = -r_new + beta * p;
        
        % Update residual
        r = r_new;
    end
    
    d = x;  % Return the search direction
end
