function [xout, hist, iters, f_values] = nonlinear_cg3(fg, x, max_iterations, ftol, gtol)
    % fg: Function that computes the objective value and gradient
    % x: Initial guess
    % max_iterations: Max number of iterations
    % ftol: Function tolerance for convergence
    % gtol: Gradient norm tolerance for convergence
    
    % Initialization
    hist = [];        % Store the history of function values
    f_values = [];    % Store function values
    iters = 0;        % Iteration count
    [f, g] = feval(fg, x);  % Initial function value and gradient
    f_values(end+1) = f;    % Save initial function value
    p = -g;                 % Initial search direction (negative gradient)

    % Main loop
    while iters < max_iterations
        % Perform line search to find step size alpha
        alpha = line_search(fg, x, p);  % Line search method
        x_new = x + alpha * p;          % Update solution

        % Compute new function value and gradient
        [f_new, g_new] = feval(fg, x_new);

        % Save function value
        f_values(end+1) = f_new;

        % Display iteration information
        disp(['Iteration: ', num2str(iters), ' | Function Value: ', num2str(f_new), ' | Gradient Norm: ', num2str(norm(g_new))]);

        % Check convergence
        if norm(g_new) < gtol || abs(f_new - f) < ftol
            break;  % Stop if gradient norm or function change is small enough
        end

        % Compute beta using Polak-Ribière (or use Fletcher-Reeves as an alternative)
        beta = max(0, (g_new' * (g_new - g)) / (g' * g));  % Polak-Ribière
        % beta = (g_new' * g_new) / (g' * g);  % Fletcher-Reeves (alternative)

        % Update search direction
        p = -g_new + beta * p;

        % Update variables for next iteration
        x = x_new;
        g = g_new;
        f = f_new;
        iters = iters + 1;

        % Store function value history
        hist(end+1) = f_new;
    end

    xout = x;  % Final optimized parameters
end

% Line search function (example, can be replaced with a more advanced method)
function alpha = line_search(fg, x, p)
    % Simple backtracking line search
    alpha = 1;  % Initial step size
    c = 1e-4;   % Armijo condition parameter
    rho = 0.5;  % Step size reduction factor
    [f, g] = feval(fg, x);  % Evaluate function and gradient at current x
    while feval(fg, x + alpha * p) > f + c * alpha * (g' * p)
        alpha = rho * alpha;  % Reduce step size
    end
end