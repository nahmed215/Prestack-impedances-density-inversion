function [xout, hist, iters, f_values] = wei_adam(fg, x, max_iterations, ftol, gtol, alpha, beta1, beta2, epsilon)
    % Initialization
    n = length(x);
    xout = x;
    hist = [];
    f_values = []; % Initialize array to store function values at each iteration
    iters = 0;

    % Initialize moment estimates
    m = zeros(n, 1); % First moment
    v = zeros(n, 1); % Second moment
    t = 0;           % Time step

    % Main Loop
    while iters < max_iterations
        t = t + 1;

        % Call the objective function and gradient
        [f, g] = feval(fg, xout);
        f_values(end + 1) = f;  % Store the function value

        % Update moment estimates
        m = beta1 * m + (1 - beta1) * g;
        v = beta2 * v + (1 - beta2) * (g .^ 2);

        % Compute bias-corrected moment estimates
        m_hat = m / (1 - beta1^t);
        v_hat = v / (1 - beta2^t);

        % Update parameters
        x_new = xout - (alpha * m_hat) ./ (sqrt(v_hat) + epsilon);

        % Check convergence based on function value change
        [f_new, g_new] = feval(fg, x_new);
        if abs(f_new - f) < ftol
            break;
        end

        % Check convergence based on gradient norm
        if norm(g) < gtol
            break;
        end

        % New convergence criteria: change in x, maximum gradient component
        xtol = 1e-5; % Relative tolerance for parameter change
        if norm(x_new - xout) < xtol
            break;
        end

        max_grad_tol = 1e-5; % Maximum component of gradient tolerance
        if max(abs(g)) < max_grad_tol
            break;
        end

        % Display iteration info every 100 iterations
        if mod(iters, 100) == 0
            disp(['Iteration: ', num2str(iters), ' | Function Value: ', num2str(f), ' | Gradient Norm: ', num2str(norm(g))]);
        end

        % Store the history for later plotting
        hist(end + 1) = f;
        iters = iters + 1;

        % Update current point
        xout = x_new;
    end
    % Return the optimized parameters and function values history
    xout = x_new; % Return optimized parameters
end
